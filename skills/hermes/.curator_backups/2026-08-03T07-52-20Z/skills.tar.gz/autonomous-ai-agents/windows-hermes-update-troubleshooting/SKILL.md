---
name: windows-hermes-update-troubleshooting
description: "Troubleshooting hermes update failures on Windows, especially when Hermes Desktop app is running."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, troubleshooting, update, hermes]
    related_skills: [hermes-agent]
---

# Windows hermes update Troubleshooting

## Issue: `hermes update` fails with "Other Hermes processes are running"

On Windows, the Hermes Desktop app keeps native `.pyd` extension files locked. The update command will fail:

```
✗ Other Hermes processes are running from this install's venv:
  PID 17648  python.exe ...\venv\Scripts\python.exe -m hermes_cli.main serve --host 127.0.0.1 --por  ← Hermes Desktop backend
```

## Root Cause

On Windows, `.pyd` files (Python extension modules) are locked by the running process. The Hermes Desktop backend keeps these files open, preventing the update from replacing them. This is a Windows-specific behavior - on Linux/macOS, files can be replaced while in use.

## Solutions

### 1. Close the Hermes Desktop App (Recommended)
- Close the Hermes Desktop app completely
- Re-run `hermes update`
- This is the safest approach

### 2. Use `--force-venv` Flag (Use with Caution)
```bash
hermes update --force-venv
```
**Warning:** May leave broken state if interrupted. Only use when Desktop app is confirmed closed.

### 3. Manual Git Update (Most Reliable for Git-Installed Hermes)
```bash
cd "$HERMES_HOME/hermes-agent"
git fetch --depth=1 origin
git reset --hard origin/main
```

### 4. Update Hangs/Times Out
If `hermes update` hangs or times out:
- The automated update may have issues with git state
- Use manual git update (see above)
- Or run in a fresh terminal session with no other Hermes processes

## Issue: "Another git process seems to be running in this repository" (stale index.lock)

Symptom: any git command in `$HERMES_HOME/hermes-agent` fails with "Another git process
seems to be running in this repository, e.g. an editor opened by 'git commit'."

Root Cause: a leftover `.git\index.lock` from a crashed/interrupted git process
(e.g. a previous `hermes update` killed mid-run).

Fix:
```powershell
# 1. Confirm no other git/hermes update process is actually running (Task Manager / Get-Process git)
# 2. Remove the stale lock:
Remove-Item "$env:LOCALAPPDATA\hermes\hermes-agent\.git\index.lock"
# 3. Re-run the update
```

Verification: `git reset --hard origin/main` SUCCEEDING is itself proof the lock is
cleared (reset also needs the index lock). After a successful manual reset, HEAD is at
origin/main but the running Hermes process still uses the OLD code — close the Desktop
app and restart Hermes for the new code to load. If dependencies changed in the update,
follow with `hermes update --force-venv` (Desktop closed) or reinstall the venv.

## Issue: "Unable to create '.git/shallow.lock': File exists" (stale shallow lock)

Symptom: `git fetch --depth=1 origin` fails with
`fatal: Unable to create '.../.git/shallow.lock': File exists` — a stale lock from a
crashed SHALLOW fetch (Hermes installs use `--depth=1` shallow clones).

Diagnosis hint: a *live* concurrent git process (stray `hermes update`, editor, or
another terminal on the same repo) may be the real holder. Evidence of this: two
consecutive `git reset --hard origin/main` yielding DIFFERENT commits with no fetch in
between. Check with:
```powershell
Get-Process | Where-Object { $_.Name -match 'git|update' } | Select-Object Id, Name, StartTime
```

Fix:
```powershell
# kill any real stray git/update process first, then:
Remove-Item "$env:LOCALAPPDATA\hermes\hermes-agent\.git\shallow.lock"
Remove-Item "$env:LOCALAPPDATA\hermes\hermes-agent\.git\index.lock"   # if present
# re-fetch (plain fetch also clears stale shallow refs):
git fetch origin main
git reset --hard origin/main
git status   # expect: On branch main, up to date, working tree clean
```

## Prevention

- Always close the Desktop app before updating
- Consider using the CLI (`hermes`) for updates when possible
- For git-installed Hermes, prefer manual git updates for better control

## Related

- See `hermes-agent` skill for general Hermes troubleshooting
- Windows-specific quirks are documented in the `hermes-agent` skill under "Windows-Specific Quirks" section