---
name: github-actions-ci-debugging
description: Diagnose and fix GitHub Actions CI/CD failures via the public API — locate a run by run_number (not run_id), find the failing job/step, extract precise JSON past web_extract truncation, check the common root causes (swallowed stderr, VPS-only build contexts, pnpm version pinning, tsconfig alias mismatch, SSH auth vs reachability), and ship the fix even with no terminal. Use when any workflow run is red or the user says fix CI #NNN / build failed / deploy failed.
---

# GitHub Actions CI Debugging

## When to use
- A GitHub Actions run is failing and you must find which job/step failed and why.
- User says 「修復 CI #NNN」「build 紅了」「deploy 失敗」on any repo (esggo, aistation, …).

## Step 1 — Locate the run (run_number ≠ run_id)
- `GET /repos/{owner}/{repo}/actions/runs/{run_id}` — the numeric path in the run URL IS the run_id.
- When the user quotes `#1545`, that is usually the workflow's **run_number**, not the id. To resolve:
  1. `GET /repos/{owner}/{repo}/actions/workflows` → find workflow by name (`OmniCore CI` → `ci.yml` → id).
  2. `GET .../workflows/{id}/runs?per_page=100&page=N` — results are **newest-first**, so run_number N is item `(latest_run_number − N + 1)`. CI with ~1500 runs: `page=16` covers ~1501–1600.
  3. Confirm the item's `run_number` field, then use that item's `id`.
- **Job logs endpoint** (`actions/jobs/{job_id}/logs`) returns `403 Must have admin rights` on public repos without a token — do not rely on it; infer from the workflow file + commit diff instead.

## Step 2 — Find the failing step
`GET .../actions/runs/{run_id}/jobs` → each job has `steps[]` (name + conclusion). First step with `conclusion=failure` is the culprit; later steps are `skipped`. Watch `needs:` chains — a failing upstream job skips dependents (`skipped` is normal, not a bug). If the job you were asked to fix shows `skipped`, the real failure is an UPSTREAM `needs:` job — diagnose that one first (verified 2026-08-02: esggo `Build Check` was `skipped` because `Vitest Tests` failed, so the import fixes could not even be exercised until the test job passed). Correlate the failing step's shell code against the raw workflow from `raw.githubusercontent.com/{owner}/{repo}/{branch}/.github/workflows/{file}` (authoritative, not local clones).

## Step 3 — Extract precise JSON past truncation
`web_extract` truncates large API responses to head+tail (15k chars), hiding middle items. Instead:
1. `browser_navigate` directly to the API URL (renders the JSON).
2. `browser_console` with `JSON.parse(document.body.innerText)` + map/filter to a compact list (e.g. `d.jobs.map(j => ({name, conclusion, steps: j.steps.map(s => s.name+':'+s.conclusion)}))`).
Returns a small clean result; no truncation, no cache-file spelunking. (Cache files live on the Hermes host — `file://` reads are usually blocked, don't chase them.)

### Failure messages WITHOUT login: check-run annotations are public
Step logs need auth, but `GET /repos/{owner}/{repo}/check-runs/{check_run_id}/annotations` is PUBLIC — no token. Returns `[{path, start_line, annotation_level, message}]` with the real failure text (verified: `Process completed with exit code 127` at workflow line 45 — command-not-found — plus Node20-deprecation warnings). Get `check_run_id` from `GET /commits/{sha}/check-runs` (map by `name`), or read annotations of every failing check in one pass. The `message` field is often enough to skip the whole log-in hunt.

## Step 4 — Common root causes (check in this order)
1. **Swallowed errors** — the failing step pipes `2>/dev/null` so the real error never surfaces. Grep the workflow for `2>/dev/null` in that step; fix = remove the redirect (or demote the check to a warning) so failures are visible.
2. **Docker build context** — `docker-compose.yml` with `build.context: /opt/...` (VPS-only absolute path) fails `docker compose config --quiet` on the runner (path doesn't exist). Runner-safe fix: relative `context: ..`. `docker build --check` also depends on context content (COPY sources) — when the context only exists on prod, demote to warning.
3. **pnpm/action-setup version resolution** — `version: 11` (bare major) can fail resolution in 1s while `version: 11.5.2` (exact, matching `packageManager` in package.json) works. Always pin the full version.
4. **tsconfig alias mismatch (Next.js root app router)** — root `lib/` is imported `@lib/...` while `@/lib/...` resolves to `src/lib/`. **DANGER: never blanket-rewrite every `@/lib/` match.** In monorepos (esggo) BOTH `src/lib/` (real implementation) and `lib/` (thin shim layer) can exist, and both aliases are defined in tsconfig — most `@/lib/` imports are then legitimately resolvable. Verified 2026-08-02 on esggo: of 30 import targets only **9** were genuinely broken (missing from `src/lib/` but present in `lib/`); a blanket sed rewrote 74 files / 104 spots, and 21 targets were mis-scoped — 15 of them created NEW `Module not found` errors because `lib/` didn't contain them (e.g. `village-seeder`, `rate-limit`, `zkp-service`, `celestial/implementation`, `api-utils`×65 files). Verify FIRST, then rewrite only the broken targets:
   1. Read `tsconfig.json` `paths` (`@/*`→`./src/*`, `@lib/*`→`./lib/*`).
   2. `GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1` → collect `lib/` and `src/lib/` file lists (filter in `browser_console` to keep context small).
   3. Extract every import target from the PR diff (`pull/{n}.diff` or local `git diff`) — static `from '...'` AND dynamic `import('...')` (blanket sed misses dynamic imports).
   4. Rewrite `@/lib/X`→`@lib/X` ONLY when X exists in `lib/` AND NOT in `src/lib/`; leave (or revert) everything else. Then re-verify: every remaining `@lib/X` must exist in `lib/`, every remaining `@/lib/X` must exist in `src/lib/`.
5. **SSH deploy fails in ~3s** — a `ssh-keyscan` step succeeding only proves TCP reachability (port open). Keyscan OK + ssh step dead in 3s = **key authentication failure** (`Permission denied (publickey)`), not network. Check the SSH secret is current, not CRLF-corrupted when written via `printf '%s\n' "${{ secrets.X }}"`, and still matches the VPS `authorized_keys`.

## Step 5 — Ship the fix with no terminal / no token
Use a Hermes cron job as the automation bridge into the user's local checkout:
- `cronjob action=create`, `workdir=<absolute local repo checkout>`, `schedule="1m"`, `deliver="origin"`.
- Prompt must be fully self-contained: exact sed/python edit commands, git branch → commit → push, `gh pr create --base main`, and a final step-by-step success/failure report (gh is usually already authed on the user's host).
- One-shot agent cron jobs **disappear from the job list after running** (they are removed, not lingered) and delivery can silently fail — verify the fix by checking the repo/PR on GitHub, never by trusting job-list state.
- When the automation path fails, hand the user a copy-paste sed + commit command block instead of stopping.
- **Non-ASCII PR bodies from the .bat/PowerShell path arrive as mojibake** (PS 5.1 argv → ANSI codepage, Big5 on zh-TW; `chcp 65001` does NOT help). Have the staged script write the body to a UTF-8 file and call `gh pr create --body-file` / `gh pr edit N --body-file` — never `--body "中文"` through argv. ASCII titles/messages are safe via argv.

## References
- `references/esggo-omnicore-ci-2026-08.md` — esggo OmniCore CI #1545/#1547 case: full evidence chain, run math, exact repairs, and repo-structure facts (vps/docker-compose.yml `/opt/esggo` context; learning-center merged into monorepo as `apps/learning-center`).
- `references/esggo-omnicore-ci-2026-08-02.md` — round-2 evidence (PR #416): the 30-target import comparison (9 genuinely broken vs 21 mis-scoped), proof that blanket `@/lib/`→`@lib/` sed creates new breakage, CI check-run table, and the `--body-file` mojibake fix.
