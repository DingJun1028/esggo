---
name: esggo-key-rotation
description: ESG-GO 金鑰輪換流程與最佳實踐涵蓋 Supabase、Gemini、GitHub Secrets、Vercel 環境變數更新與迭代記錄
version: v1.0
---

# ESG-GO 金鑰輪換流程 v1.0

## 輪換步驟

1. 在對應平台 (Supabase Dashboard、Google AI Studio 等) 產生新金鑰
2. 更新 GitHub Secrets: `gh secret set <KEY_NAME> --body "<new_key>"`
3. 更新 Vercel 環境變數 (如適用)
4. 記錄迭代至 `iteration-log.txt`
5. 存檔至 Hindsight 記憶庫

## 金鑰格式注意

- Supabase 新格式金鑰以 `sb_publishable_` 或 `sb_secret_` 為前綴
- 舊版 JWT 格式金鑰以 `eyJhbG` 為前綴
- 兩種格式均需同等處理
- Gemini API Key 格式: `AQ.<base64>` (新版 AI Studio 格式)

## 完整金鑰清單

| 金鑰 | 平台 | 更新方式 |
|------|------|----------|
| VITE_SUPABASE_ANON_KEY | GitHub Secrets | `gh secret set` |
| SUPABASE_SERVICE_ROLE_KEY | GitHub Secrets | `gh secret set` |
| VITE_SUPABASE_URL | GitHub Secrets | `gh secret set` |
| NEXT_PUBLIC_GEMINI_API_KEY | GitHub Secrets | `gh secret set` |
| GOOGLE_API_KEY | GitHub Secrets | `gh secret set` |
| OPENAI_API_KEY | GitHub Secrets | `gh secret set` |
| VERCEL_API_KEY | GitHub Secrets | `gh secret set` |
| OPENROUTER_API_KEY | GitHub Secrets | `gh secret set` |
| FIREBASE_* | GitHub Secrets / Vercel | `gh secret set` / `vercel env add` |

## 更新腳本範例

```powershell
$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
chcp 65001 | Out-Null

$githubRepos = @("DingJun1028/esggo", "DingJun1028/esggo-learning-center")

# Supabase
$supaAnon = "sb_publishable_..."
$supaRole = "sb_secret_..."
# Gemini
$gemini = "AQ...."

# OpenAI / Vercel / OpenRouter
$openai = "sk-proj-..."
$vercel = "vcp_..."
$openrouter = "sk-or-v1-..."

foreach ($repo in $githubRepos) {
  gh -R $repo secret set NEXT_PUBLIC_GEMINI_API_KEY --body $gemini
  gh -R $repo secret set GOOGLE_API_KEY --body $gemini
  gh -R $repo secret set OPENAI_API_KEY --body $openai
  gh -R $repo secret set VERCEL_API_KEY --body $vercel
  gh -R $repo secret set OPENROUTER_API_KEY --body $openrouter
  gh -R $repo secret set VITE_SUPABASE_ANON_KEY --body $supaAnon
  gh -R $repo secret set SUPABASE_SERVICE_ROLE_KEY --body $supaRole
  gh -R $repo secret set VITE_SUPABASE_URL --body "https://yhwfmavnhaivvgzeuklx.supabase.co"
}

# Vercel 環境變數
vercel env add NEXT_PUBLIC_GEMINI_API_KEY production
vercel env add GOOGLE_API_KEY production
vercel env add OPENAI_API_KEY production
vercel env add VERCEL_API_KEY production
vercel env add OPENROUTER_API_KEY production
```

## 輪換後驗證

```powershell
gh -R "DingJun1028/esggo" secret list
gh -R "DingJun1028/esggo-learning-center" secret list
```

## 注意事項

- PowerShell 5.1 使用 `System.IO.File` / `[System.Text.UTF8Encoding]` 處理 UTF-8 No BOM，避免中文亂碼
- 如遇 PowerShell `curl` 別名問題，請改用 `curl.exe`
- 新金鑰應分段提供；完成後應清除聊天紀錄中的敏感字樣

## 已確認的金鑰格式 (2026-07-30)

- Supabase anon: `sb_publishable_qQJgz065fNMMUAxWzfUa1w_YviyrDx6`
- Supabase service_role: `sb_secret_bbyNAmUF5FUiCbhjwVfUfw_LQcCCcsv`
- Gemini API Key: `AQ.Ab8RN6LCLwYa0LKsLLczAw8-oUbshHWg6BmNQylWXHUPTOhHlQ`