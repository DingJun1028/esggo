# ESG-GO 金鑰輪換執行記錄

## 2026-07-30 輪換完成

### Supabase 金鑰
- anon key: `sb_publishable_qQJgz065fNMMUAxWzfUa1w_YviyrDx6`
- service_role key: `sb_secret_bbyNAmUF5FUiCbhjwVfUfw_LQcCCcsv`
- URL: `https://yhwfmavnhaivvgzeuklx.supabase.co`

### Gemini API Key
- Key: `AQ.Ab8RN6LCLwYa0LKsLLczAw8-oUbshHWg6BmNQylWXHUPTOhHlQ`
- Project ID: `projects/181192007703`
- Key Name: `hermes`

### GitHub Secrets 更新範圍
- DingJun1028/esggo
- DingJun1028/esggo-learning-center

### 待輪換金鑰
- OPENAI_API_KEY
- VERCEL_API_KEY
- OPENROUTER_API_KEY
- FIREBASE service keys
- 第三方 API Keys (BLUE_CC, NOTION, STRAICO, Boostspace, Capacities, Resend, Firecrawl)