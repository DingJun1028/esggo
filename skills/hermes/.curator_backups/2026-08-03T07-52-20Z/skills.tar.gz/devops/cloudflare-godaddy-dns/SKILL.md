---
name: cloudflare-godaddy-dns
description: "Cloudflare DNS + GoDaddy domain management: API/CLI provisioning, A records, CNAME, SSL prerequisites via certbot/cloudflared, and failed-CLI fallback patterns."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [DNS, Domains, Cloudflare, GoDaddy, DevOps, SSL]
---

# Cloudflare + GoDaddy DNS / Domain Automation

Manage `esggo.co` and subdomains across Cloudflare and/or GoDaddy. Covers when the named CLIs/tools are absent, when to use direct REST API, and how to hand off to certbot once DNS resolves.

## Quick triage: where is the domain registered?

1. Run `whois esggo.co | grep -i "Registrar\|Name Server"` to identify registrar and nameservers.
2. If nameservers point to Cloudflare, use Cloudflare API/CLI.
3. If nameservers point to GoDaddy, use GoDaddy REST API directly.
4. If nameservers are still at the registrar but API access is unavailable, fall back to guiding the user through the registrar console UI.

## Required credentials (ask user / secret manager once)

- Cloudflare: `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` (token must include `DNS: Edit` and, if tunnels are used, `Tunnel: Edit`)
- GoDaddy: `GODADDY_API_KEY` + `GODADDY_API_SECRET`
- VPS target: known public IP (`161.118.252.147`) and SSH path (`C:\Project\ESGGO VPS\id_rsa_esggo_real`)

Store via `gh secret set` into `esggo_vps` before server-side automation.

## Cloudflare: preferred path

### Install cloudflared (daemon/tunnel agent)
```bash
# Debian/Ubuntu VPS
curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb -o /tmp/cf.deb
sudo dpkg -i /tmp/cf.deb
```

### Optional: Cloudflare Wrangler CLI
```bash
npm install -g wrangler
wrangler login
```
Wrangler is convenient for DNS wrangling but **not required**. If absent, do direct `curl` to `https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records`.

### Cloudflare DNS records for `esggo.co`
```bash
ZONE_ID=$(curl -sS -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  https://api.cloudflare.com/client/v4/zones?name=esggo.co | jq -r '.result[0].id')

# Apex and www
for host in @ www; do
  curl -sS -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records" \
    -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
    -H "Content-Type: application/json" \
    --data "{\"type\":\"A\",\"name\":\"${host}\",\"content\":\"161.118.252.147\",\"ttl\":1,\"proxied\":false}" | jq .
done

# ftg subdomain
curl -sS -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"type":"A","name":"ftg","content":"161.118.252.147","ttl":1,"proxied":false}' | jq .
```

### Cloudflare quick caveats
- `proxied` must be `false` for root A records pointing to non-Cloudflare origins if you still serve directly from the VPS IP.
- TTL `1` = automatic.
- DNS changes propagate through Cloudflare quickly but client caches may need time.

## GoDaddy: direct REST API fallback

GoDaddy has **no official public CLI**. Use REST API with Basic Auth.

```bash
# List domains to confirm ownership
curl -sS -u "$GODADDY_API_KEY:$GODADDY_API_SECRET" \
  "https://api.godaddy.com/v1/domains?statuses=ACTIVE" | jq .

# Get existing records
curl -sS -u "$GODADDY_API_KEY:$GODADDY_API_SECRET" \
  "https://api.godaddy.com/v1/domains/esggo.co/records/A/@"

# Replace @ and www A records
curl -sS -X PUT -u "$GODADDY_API_KEY:$GODADDY_API_SECRET" \
  -H "Content-Type: application/json" \
  "https://api.godaddy.com/v1/domains/esggo.co/records/A/@|www" \
  -d '[{"data":"161.118.252.147","ttl":600,"type":"A","name":"@"},{"data":"161.118.252.147","ttl":600,"type":"A","name":"www"}]'

# Add ftg A record if missing
curl -sS -X PUT -u "$GODADDY_API_KEY:$GODADDY_API_SECRET" \
  -H "Content-Type: application/json" \
  "https://api.godaddy.com/v1/domains/esggo.co/records/A/ftg" \
  -d '[{"data":"161.118.252.147","ttl":600,"type":"A","name":"ftg"}]'
```

### GoDaddy API notes
- Provider-required TTL minimum is commonly `600`.
- `@` is the GoDaddy representation for the apex/root domain.
- Some API endpoints enforce exact-match names; use `www` and `ftg` as-needed per subdomain.

## OmniCLI: explicit gap

`OmniCLI` is referenced as a user preference but is **not a generally available public tool identity** in this environment. Do not fabricate commands. If the user insists on OmniCLI, request the install path or exact binary/package name, or execute the equivalent canonical API path above instead.

## Nginx preparation on VPS

Before DNS/SSL:
- `esggo.co / www.esggo.co` must reverse-proxy `127.0.0.1:3000`
- `ftg.esggo.co` must serve `/var/www/ftg-tours/` with `try_files $uri $uri/ /index.html`
- Include `location /.well-known/acme-challenge/ { root /var/www/certbot; }` in both server blocks for HTTP-01 validation.

Deploy with `ssh` + `sudo tee` from a heredoc, then `sudo nginx -t && sudo systemctl reload nginx`.

## SSL handoff sequence

After DNS propagation:
1. Verify records: `for h in esggo.co www.esggo.co ftg.esggo.co; do nslookup $h; done`
2. SSH into VPS.
3. Run:
```bash
sudo certbot --nginx -d esggo.co -d www.esggo.co -d ftg.esggo.co
```
4. Confirm auto-renew:
```bash
sudo certbot renew --dry-run
```

## Failed-CLI fallback pattern

If a requested CLI/tool is not installed or does not exist:
1. Stop after one install attempt.
2. Switch to direct REST API or `curl` + `jq`.
3. Tell the user exactly what was missing and what you switched to.
4. Do not retry the same install path multiple times in the same turn.
