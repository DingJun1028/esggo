---
name: esggo-automation-practices
description: Class-level ESG-GO automation playbook covering secret rotation, OpenCode+Hindsight integration, agents-cli workflows, and PowerShell/Firebase setup conventions.
version: v1.0
---

# ESG-GO Automation Practices

## PowerShell Automation
- Use UTF-8 without BOM for file writes: `New-Object System.Text.UTF8Encoding $false`
- Fix terminal Chinese display: `$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new(); chcp 65001 | Out-Null`
- Avoid alias `curl`; use `curl.exe` or remove alias.

## Secret Rotation
- Providers: Supabase, Gemini, OpenAI, Vercel, OpenRouter, Firebase, third-party APIs.
- Default repo target: `DingJun1028/esggo`.
- `DingJun1028/esggo-learning-center` is excluded unless the user explicitly requests changes there.
- Order: Supabase/Gemini first, then Firebase/web app config, then third-party APIs.
- After rotation: update GitHub Secrets, update Vercel env vars, then restart Hermes and record.

## Repo Boundaries
- Use `esggo` for automation, config changes, and deployment work by default.
- Do not touch `esggo-learning-center` unless explicitly instructed.
- Allowed sync target: `esgo_VPS`.

## OpenCode + Hindsight
- Config path: `~/.config/opencode/opencode.json`
- Enable: `hindsight.enabled=true`, `autoRecall=true`, `autoRetain=true`, `compactionHook=true`
- Server: `opencode serve --hostname 0.0.0.0 --port 4096`
- Security: set `OPENCODE_SERVER_PASSWORD`
- Windows: prefer WSL; access Windows files under `/mnt/c/`

## agents-cli
- Install: `uvx google-agents-cli setup`
- Scaffold: `agents-cli scaffold esggo-agent`
- Run: `agents-cli run "<prompt>"`
- Validate: `agents-cli eval generate`, `agents-cli eval grade`
- Deploy: `agents-cli deploy`

## Firebase
- Project ID: `esggo-504004`
- Project number: `1048542533112`
- Register web app in Firebase Console; set hosting; deploy with Firebase CLI.
- Keep web app config and service account keys in GitHub Secrets and Vercel env vars.

## Record Keeping
- Append automation results to `iteration-log.txt`.
- Store durable facts in `hindsight_retain`.
- If execution tools are blocked, provide deterministic manual instructions and cron-based reminders.

## Cron / Headless Execution Constraints

- Cron sessions do **not** expose `terminal` / SSH / `execute_code` subprocess tools. Any attempt to `docker ps` or shell into the VPS from a cron job will fail with `Tool 'terminal' does not exist` or `BLOCKED: execute_code runs arbitrary local Python`.
- Do not fabricate container health states in cron mode. Report honestly: list what could not be verified, the known-good baseline (if any), and the exact recovery command the user should run.
- Last known-good Docker baseline for ESG-GO VPS: `6/6 healthy` — containers `esggo-core`, `omniagent-gateway`, `esggo-redis`, plus system `nginx` on `:80/:443`.
- Canonical VPS IP/SSH target: `161.118.248.180` (hostname alias: `esggo-vps` / `esggo-vps-root` / `esggo-vps-fix`). Verify that scripts and snapshots use this IP, not stale historical IPs from prior sessions.

## Windows Computer Use Caveats

- `computer_use` is a background driver; foreground keystrokes go to whichever window is active, so `Win+R`, `Ctrl+Esc`, and other shell hotkeys do not reliably open Start/Run.
- Background clicks to Electron apps sometimes land as `suspected_noop`; if that happens, escalate to foreground via `delivery_mode='foreground'` rather than blind-retrying.