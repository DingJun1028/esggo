---
name: spa-deploy-and-cdn-debug
description: >
  Deploy and debug SPAs (Vite/React) on VPS behind Cloudflare. Use when:
  - Site goes blank after deploy and console shows Rocket Loader / import.meta errors
  - Cloudflare Dashboard toggle alone doesn't fix the issue
  - Need to verify if SPA is actually rendering despite empty raw HTML
  - Need to inject inline JS patches safely without creating duplicate blocks
---

# SPA Deploy & Cloudflare/CDN Debug

## Trigger
- FTG or any Vite/React SPA returning HTTP 200 with empty `#root`
- Cloudflare Rocket Loader errors after deploy
- Inline JS patch accidentally duplicated in `index.html`
- SPA works locally but blank behind Cloudflare

## Deploy Flow

### Standard deploy
1. Build locally: `pnpm run build` → `dist/`
2. Transfer: `scp -r dist/* ubuntu@<vps>:/var/www/<site>/`
3. Reload: `ssh ubuntu@<vps> 'sudo systemctl reload nginx'`

### Push-to-deploy via GitHub Actions (preferred)
Create `.github/workflows/deploy-vps.yml`:
```yaml
on:
  push:
    branches: [master]
    paths: ['<project-dir>/**']

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22 }
      - run: pnpm install --frozen-lockfile && pnpm run build
      - run: |
          mkdir -p ~/.ssh
          echo "${{ secrets.VPS_SSH_KEY }}" > ~/.ssh/id_rsa
          chmod 600 ~/.ssh/id_rsa
          scp -r dist/* ubuntu@<vps>:/var/www/<site>/
          ssh ubuntu@<vps> 'sudo systemctl reload nginx'
```

## Cloudflare Blank-Site Debugging (6-step)

### Step 1: Confirm Rocket Loader is really off
- Dashboard → Speed → Optimization → Rocket Loader → Off
- Caching → Purge Everything
- Wait 60–120 seconds before testing

### Step 2: Rebuild with import.meta patch if needed
When Rocket Loader cannot be fully disabled, inline JS into `index.html` and patch:
```python
import re
from pathlib import Path

html = Path('dist/index.html').read_text()
js = Path('dist/assets/[hash].js').read_text()

for bad, good in [
    ('import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href', 'new URL(e,location.href).href'),
    ('import.meta.url', 'location.href'),
    ('import.meta.resolve', 'function(x){return new URL(x,location.href).href;}'),
]:
    js = js.replace(bad, good)

# Escape </script> so HTML parser doesn't truncate
js = js.replace('</script>', '<\\/script>')

# Inline into first <script> tag
m = re.search(r'(<script[^>]*>)(.*?)(</script>)', html, re.DOTALL)
fixed = html[:m.start()] + m.group(1) + js + m.group(3) + html[m.end():]
Path('dist/index.html').write_text(fixed)
```

**Note**: `data-cf-rl="false"` alone often fails on Free plan. Inline is more reliable, but must be deduped.

### Step 3: Deduplicate inline blocks
Repeated inline patches create duplicate `<script>...</script>` blocks and silently break React mount. After every inline patch, run:
```python
import re
html = open("index.html","r",encoding="utf-8").read()
html = re.sub(r'(?s)(<script crossorigin[^>]*>.*?</script>)\s*(<script crossorigin[^>]*>.*?</script>)+', r'\1', html)
open("index.html","w",encoding="utf-8").write(html)
```

### Step 4: Debug silent React mount failures
If site is still blank but no console errors, wrap mount with try-catch to expose hidden errors:
```
var dr=document.getElementById(`root`);
if(dr){
  try{ $n.createRoot(dr).render(x.createElement(ur,null)); }
  catch(e){ console.error("[FTG-MOUNT-ERR]",e); dr.innerHTML="<pre style=\\"color:red;padding:2rem\\">"+JSON.stringify(e&&e.message||String(e))+"</pre>"; }
}
```
This renders the error message directly on the page.

### Step 5: Verify rendering correctly
Raw HTML curl always shows empty `<div id="root">` for SPAs (that's normal). Verify with:
- Browser screenshot showing actual rendered content
- Browser console: `document.getElementById('root').innerHTML.length` should be > 0
- Check delivered HTML has no `rocket-loader.min.js`
- Check inline `<script>` does not contain `import.meta`

### Step 6: Nginx cache hygiene
Add to site config to prevent stale serving:
```
location / { add_header Cache-Control "no-store" always; }
```

## Pitfalls
- `data-cf-rl="false"` does NOT consistently override Rocket Loader on Free plan
- Dashboard Off toggle does NOT take effect until Purge Everything completes
- Duplicate inline `<script>` blocks don't throw errors; they just render nothing
- Browser console eval may return `about:blank` in sandboxed environments; verify with screenshot + manual inspection instead
- SSH heredocs are fragile with Python; prefer `execute_code` or write-then-run scripts over inline heredoc with quotes

## Platform Notes
- Deploy via scp to VPS `/var/www/ftg-tours/`
- Run `sudo systemctl reload nginx` after deploy
- VPS IP: 161.118.252.147, user: ubuntu, SSH key: read directly from local file
