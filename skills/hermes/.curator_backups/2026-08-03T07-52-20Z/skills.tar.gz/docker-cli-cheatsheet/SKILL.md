---
name: docker-cli-cheatsheet
description: "Corrected, battle-tested Docker CLI reference. Use when building images, running containers, debugging a Docker host, or writing Dockerfiles/compose. Includes fixes for common cheat-sheet errors (--no-cache placement, daemon startup, shell-in-container, prune -a) and the high-frequency commands most references omit (compose, --rm, batch cleanup, volumes, networks, buildx)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [docker, cli, cheatsheet, containers, devops, reference]
---

# Docker CLI Cheat Sheet (corrected)

A pragmatic Docker command reference. Corrections vs. common cheat sheets are flagged with ⚠.

## Build images
```bash
docker build -t <image_name> .                       # build from Dockerfile in cwd
docker build -t <image_name> --no-cache .            # ⚠ --no-cache goes BEFORE the context '.'
docker build -t <image_name> -f path/Dockerfile .    # custom Dockerfile path
docker buildx build --platform linux/amd64,linux/arm64 -t <image> .   # multi-arch
```
⚠ Common error: `docker build -t name . no-cache` puts `no-cache` AFTER the build context `.`
and fails. `--no-cache` is a build flag — place it before the final `.` argument.

## Images
```bash
docker images                  # list local images
docker rmi <image_name|id>     # delete an image
docker image prune             # remove dangling (untagged) images only
docker image prune -a          # ⚠ add -a to also remove all unused images (not just dangling)
docker search <term>           # search Docker Hub
docker pull <image_name>       # pull from registry
docker push <user>/<image>     # publish to Docker Hub (must be logged in)
docker login -u <user>         # authenticate to a registry
```

## Run containers
```bash
docker run <image>                              # create + run (random name)
docker run --name <cname> <image>               # with a custom name
docker run -d <image>                           # detached (background)
docker run --rm <image>                         # ⚠ auto-remove container when it exits (very common)
docker run -p <host>:<container> <image>        # publish a port (e.g. -p 8080:80)
docker run -v <host>:<container> <image>        # mount a volume
docker run -e KEY=val <image>                   # set an env var
docker run -it <image> sh                       # interactive + TTY, run shell
```

## Lifecycle
```bash
docker start <cname|id>        # start a stopped container
docker stop  <cname|id>        # graceful stop
docker restart <cname|id>
docker rm <cname|id>           # remove a stopped container
docker rm -f <cname|id>        # force-remove a running container

# batch helpers (handy for cleanup)
docker stop $(docker ps -q)                       # stop all running
docker rm $(docker ps -a -q)                       # remove all containers
docker container prune                             # remove all stopped containers
```

## Inspect / debug
```bash
docker ps                       # running containers
docker ps -a                    # all containers (running + stopped)
docker logs -f <cname>          # follow logs (streaming)
docker inspect <cname|id>       # raw JSON config/state
docker container stats          # live CPU/mem/IO per container
docker exec -it <cname> sh      # shell inside a running container
# ⚠ some images lack `sh` (distroless/alpine variants) — try `bash` or `ash` instead
```

## Volumes & networks (often needed in real deploys)
```bash
docker volume ls
docker volume create <vname>
docker volume rm <vname>
docker network ls
docker network create <nname>
```

## Compose (the command you'll actually use most)
```bash
docker compose up -d           # build (if needed) + start all services in background
docker compose down            # stop + remove containers, networks (keeps volumes)
docker compose down -v         # also remove volumes
docker compose ps              # service status
docker compose logs -f <svc>   # follow a service's logs
```
Reference projects: https://github.com/docker/awesome-compose

## Daemon / host
⚠ `docker -d` is an OLD daemon flag and does NOT start the daemon on modern installs.
```bash
# Linux (systemd):
sudo systemctl start docker
sudo systemctl enable docker
docker info                     # system-wide info (confirms daemon is up)
docker --help                  # help; also: docker <subcommand> --help
```
On macOS/Windows use the **Docker Desktop** app (https://docs.docker.com/desktop) — there is no
`docker -d` there.

## Concepts (quick)
- **Image**: standalone, executable package — code + runtime + libs + settings.
- **Container**: runtime instance of an image; runs identically across hosts.
- **Docker Hub**: registry for sharing images — https://hub.docker.com
- Docs: https://docs.docker.com
