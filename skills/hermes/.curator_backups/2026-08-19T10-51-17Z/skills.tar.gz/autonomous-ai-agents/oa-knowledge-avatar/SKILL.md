---
name: oa-knowledge-avatar
category: autonomous-ai-agents
description: 萬能知識分身零時差學習迴路 — 結點孵化/分身吸收/蜂寫層同步/讀回繼承。OA-Team 第二大腦自迭代記憶螺旋。
tags: [soul, swarm, knowledge-avatar, second-brain, tencentdb, 5t, inheritance, omni]
---

# 萬能知識分身 · 零時差學習迴路

## When to use
- 使用者說「知識分身」「第二大腦學習」「結點孵化」「融會貫通傳承」「OA 蜂寫層」
- 要把 Obsidian vault 筆記變成「會自我迭代的活記憶」而非靜態存檔
- 要接 TencentDB Agent Memory 作為 OA 蜂群共享記憶後端（讀+寫雙向）

## 四相機制（本體邏輯）
1. **Hatch 孵化**：掃 vault 所有知識結點（## 標題 + [[wikilink]）→ 每結點一個萬能知識分身
2. **Absorb 吸收**：分身跟一知識點，正確+錯誤變體皆保留（當下湊齊最完整內容）
3. **Feedback 反饋**：吸收完標 absorbed → 反饋 MOC (00-Index.md) + soul
4. **Project 投向**：瞬間投向本體 (shared/types.ts) 經 sync-vault-types.ts --apply，零時差

## 五相傳承迴路（VPS cron avatar-daily.sh，每日 05:00）
```
Inherit(繼承前日) → Hatch(孵化新結點) → Write(蜂寫層) → Guard(憑證閘) → Clean(回歸)
```
- Inherit: `oa-memory-recall.mjs 'avatar'` 讀回前日記憶
- Hatch: `knowledge-avatar.mjs`
- Write: `tdai-memory-sync.mjs` 同步進 TencentDB
- Guard: `vault-access-guard.mjs` 憑證閘
- Clean: `avatar-cleanup.mjs` 清 IAvatarProbe* 測試型別

## ABC 三線
- **A 持續孵化**：VPS crontab `avatar-daily.sh`（本地 Hermes cron 已棄用，因 8420 只在 VPS 內網）
- **B 蜂寫層同步**：TencentDB Agent Memory — 寫 `/v3/conversation/add`，讀 `/v3/conversation/query`
- **C canonical 萃取**：avatar 投影 `.avatar-types.d.ts` → `sync-vault-types.ts --apply` 進 shared/types.ts

## TencentDB 端點解謎（agentmemory v3）
- Core: `http://127.0.0.1:8420`（VPS 內網，本機連不到）
- 寫入: `POST /v3/conversation/add` body `{messages:[{role:'user',content:'...'}]}`
- 讀取: `POST /v3/conversation/query` body `{query:'avatar',limit:10}`
- 認證: header `x-tdai-service-id: default` + `Authorization: Bearer <key>`
- key 來源: VPS `/opt/esggo/apps/tencentdb-memory/.admin-key`（無 env 時 fallback 讀檔）
- 錯誤路徑（勿用）: `/v3/{svc}/memory` `/v1/{svc}/memory` `/memory` 全 404

## 可觀測 + 自愈 (2026-08-13 補齊)
- `avatar-metrics.mjs` — 解析 avatar.log 末次 run 產 `avatar-metrics.json`（hatched/synced/failed/recall/healthy）
- `avatar-moc-sync.mjs` — 讀 metrics 寫回 `00-Index.md` 的「知識分身日報」狀態行（OA 蜂群可讀）
- VPS `avatar-daily.sh` 七相: Inherit→Hatch→Write(retry 3)→Guard→Clean→Metrics→MOC
- 自愈: tdai-sync 失敗自動 retry 3 次（間隔 5s）
- 健康度: `healthy = syncFailed==0 && errors==0 && guardOk`

## 腳本清單（esggo repo scripts/）
- `knowledge-avatar.mjs` — 孵化+吸收+型別投影
- `tdai-memory-sync.mjs` — 寫入蜂寫層（優雅降級：連不到時本地不丟）
- `oa-memory-recall.mjs` — 讀回（B 線雙向閉環）
- `vault-access-guard.mjs` — 公開前掃真憑證
- `avatar-cleanup.mjs` — 防回歸清測試型別
- `sync-vault-types.ts` — vault→canonical 型別同步（接 .avatar-types.d.ts）

## VPS 實證（2026-08-13）
- 孵化 138 分身（正確 129 / 錯誤 9 皆存）
- tdai-sync 91 全數同步成功（VPS 內網）
- recall 讀回 10 筆 [avatar ...] 驗證
- typecheck TC=0 / vitest 597 passed

## 資產化位置
- soul: `esggo-omni-center/soul-full.md` §26.11（ABC）/ §26.12（深入）/ §26.13（傳承）
- vault: `vault/Agents/context/OmniKnowledgeAvatar.md` + `OmniKnowledgeInheritance.md`
- 批次: f5f74ecbc(recall) / ab3980af1(cleanup) / 41764c89e(cron) / 045240abe(§26.13)

## Pitfalls
- 本地跑 tdai-sync 會 fetch failed（8420 只在 VPS）→ 正常，VPS cron 才連得到
- shared/types.ts 勿手動加 IAvatarProbe*（cleanup 會清，且污染 canonical）
- .avatar-types.d.ts / .avatar-registry.json 是 gitignored 機讀產物
- 勿用本地 Hermes cron 跑（依賴 Gemini，會 404）→ 用 VPS crontab
