---
name: windows-gitbash-fileops
description: Windows Git-Bash 陷阱：大樹複製/遷移、background 服務、殺 port 行程、UTF-8 誤判。
version: v1.0
---

# Windows Git-Bash 大樹檔案操作

Hermes `terminal` Local backend 在 Windows 上實際跑 **Git-Bash**（`/usr/bin/bash`，PWD 顯示如 `/c/Users/dingj`），不是 PowerShell。對含 `node_modules`/`.git`/`.next` 的巨型樹（數萬~十萬檔），常規 Unix 指令會踩坑。

## 致命陷阱 1：tar 管線孤兒子行程（最隱蔽）
```bash
cd /c/Project/src && tar -cf - . | (cd /c/Project/dst && tar -xf -)
```
若你用 `process(kill)` 終止整個 terminal 指令，**pipe 另一端的 tar 子行程（pid 不同）可能仍存活並持續寫入 dst**。症狀：dst 目錄檔案數**異常暴增**（如 27 檔變 2336，node_modules 被灌 1158 檔），且 `rm -rf` / `rmdir /s /q` 反覆清不掉（刪了又被寫回）。

**正確收尾**：
1. `ps aux | grep -i tar` 找出所有殘餘 tar pid
2. `kill -9 <pid1> <pid2>` 全部幹掉
3. **確認 `ps aux | grep tar` 為 NONE** 後再 `rm -rf dst/dir`
4. 重建 `cp -a` 或重新 tar

> 判斷 dst 是否髒：頂層 `ls -A` 正常但 `find -type f` 數爆量 → 深層子目錄被灌重複檔。

## 致命陷阱 2：cp -a 對大樹極慢
`cp -a src/. dst/` 含 `.git` 時，Git-Bash 逐檔 stat 每個 node，10 萬檔可跑 **17 分鐘**且中途無法簡單續傳。避免對大樹用 `cp -a`。

## 致命陷阱 3：robocopy 靜默漏拷
`robocopy SRC DST /MIR /XD .git` 回傳 EXIT=0 卻只拷了約 1/3（如 98911 → 29147 檔），整個 `node_modules`/`rules-tutorial`/`app` 變 0。原因：pnpm `.pnpm` 符號連結 + 超長路徑（>260 字元）被靜默跳過。robocopy 的 0 不代表「全成功」，只代表「已存在的一致檔無需複製」。**不要信 robocopy 的 exit code 當完整性證明**——一定要事後 `find` 比對兩側檔數。

## 致命陷阱 4：rm / rmdir 刪不掉
Git-Bash 的 `rm -rf` 與 `cmd //c "rmdir /s /q ..."` 對長路徑/鎖檔會**靜默失敗**（STILL_THERE）。可靠做法：
- 先確認無殘餘寫入行程（見陷阱 1）
- `rm -rfv dst/dir` 看輸出是否真的 removed

## 致命陷阱 5：find 全樹計數超時
`find /c/Project/bigtree -type f | wc -l` 在樹過大時會 **60s 超時**。改用輕量探針：
- 只查單一目錄：`find dst/subdir -type f | wc -l`
- 比對缺口：`comm -23 <(find src ... | sed 's#src/##' | sort) <(find dst ... | sed 's#dst/##' | sort)`

## 可靠全流程（目錄改名/全量複製，排除 .git 與 node_modules）

`node_modules` 與 `.git` 是可重建/不應搬的（node_modules 用 `npm install` 重建；.git 避免 nested repo 污染主倉）。

```bash
SRC=/c/Project/esggo-learning-center
DST=/c/Project/esggo/esggo-omni-center
mkdir -p "$DST"
# 排除兩者，tar 流式複製（比 cp -a 快、比 robocopy 可靠）
( cd "$SRC" && tar -cf - --exclude='.git' --exclude='node_modules' . ) \
  | ( cd "$DST" && tar -xf - )
# 事後比對（排除同兩項）
find "$SRC" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' | sed "s#$SRC/##" | sort > /tmp/s.txt
find "$DST" -type f -not -path '*/.git/*' -not -path '*/node_modules/*' | sed "s#$DST/##" | sort > /tmp/d.txt
comm -23 /tmp/s.txt /tmp/d.txt    # 缺的補拷：while read f; do mkdir -p "$DST/$(dirname $f)"; cp -a "$SRC/$f" "$DST/$f"; done
```

## 致命陷阱 6：background 執行 `cd X && node Y` 直接退出

```bash
terminal(background=true, command="cd /c/Project/app && node server.mjs")
```
行程立刻 exit 1，輸出只有：
```
bash: no job control in this shell
stdin is not a tty
```
Git-Bash 在非互動 background 情境下無 job control，複合指令會被打斷。**症狀容易誤判成
「程式壞了」**——實際上 `node --check` 完全通過。

**可靠做法**：包一層 wrapper，用 `exec` 取代行程：
```bash
# run.sh
#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
exec node server.mjs
```
```bash
terminal(background=true, command="bash /c/Project/app/run.sh")
```
> env 前綴（`PORT=8799 node ...`）同樣會觸發此問題 → 一併寫進 wrapper 或用 `.env` 檔。

## 致命陷阱 7：殺掉佔用 port 的行程，只有 PowerShell 可靠

Git-Bash 下這兩種寫法**都無效**（`//PID` 被 MSYS 路徑轉換吃掉；`cmd //c` 只印出 banner）：
```bash
taskkill //PID 2300 //F              # 錯誤: 無效的引數/選項 - '//PID'
cmd //c "taskkill /PID 2300 /F"      # 只回 Windows 版本 banner，沒殺到
```
**可靠做法**：
```bash
# 已知 pid
powershell -NoProfile -Command "Stop-Process -Id 2300 -Force"
# 只知 port（推薦，免先查 pid）
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 8799 -State Listen -EA SilentlyContinue | ForEach-Object { Stop-Process -Id \$_.OwningProcess -Force }"
```
驗證一定要用**主動探測**而非相信指令回傳：
```bash
curl -s -m 2 http://localhost:8799/healthz >/dev/null && echo STILL_UP || echo PORT_FREE
```

### 衍生：殘留行程造成「假失敗」
舊版行程佔住 port → 新版啟動失敗 → 測試打到**舊服務**，回報一堆 `undefined` FAIL。
凡是「本機起服務再測」的腳本，開頭都要加埠佔用守衛：
```bash
if curl -sf -m 2 http://localhost:$PORT/healthz >/dev/null 2>&1; then
  echo "✗ port $PORT 已被佔用（可能是舊版殘留行程）"; exit 1
fi
# 啟動後再確認起來的是本次版本（healthz 必須含新欄位）
curl -sf -m 3 http://localhost:$PORT/healthz | grep -q '"version"' || { echo "✗ 未正常啟動"; exit 1; }
```

## 致命陷阱 8：`read_file` 誤判 UTF-8 檔為 binary → `patch` 連帶失效

含大量中日文註解的檔案，`read_file` 可能回 `Binary file - cannot display as text`
（`total_lines: 0`），`patch` 隨即報 `Binary file — cannot display as text`，無法編輯。

**先確認檔案本身沒問題**：
```bash
file monitor-server.mjs      # → JavaScript source, Unicode text, UTF-8 text
node --check monitor-server.mjs   # → 通過
```
**繞法**：`write_file` 寫一支一次性 Python 腳本做精確字串替換，跑完即刪。
```python
import io
p = r"C:\path\to\file.mjs"
s = io.open(p, encoding="utf-8").read()
assert s.count(old) == 1, "anchor not unique"
io.open(p, "w", encoding="utf-8", newline="\n").write(s.replace(old, new))
```
- 中文字串一律寫成 `\uXXXX` escape，避免腳本本身的編碼問題。
- 每個 anchor 都加 `assert`，絕不做無聲替換。
- 收尾 `node --check` / `bash -n` 驗證，然後 `rm` 掉腳本。
> `execute_code` 在 cron / 受限 profile 下會被 BLOCKED，所以用 `write_file` + `terminal python` 而非 `execute_code`。

## 路徑與環境提示
- `C:\Project` 是**本機磁碟**，與 OneDrive 雲端無關聯（即使 Documents 下有 OneDrive 子樹，互不影響）。
- Git-Bash `cmd //c "..."` 的引號串接不穩，必要時改用 `.bat` 檔原生執行。
- `cp -a` 遇到 Windows junction/symlink 會把連結解析成實體檔堆積 → 大樹複製優先用 tar 並 `--exclude='node_modules'`。
