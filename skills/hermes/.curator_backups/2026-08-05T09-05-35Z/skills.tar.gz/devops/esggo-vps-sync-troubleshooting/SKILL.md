---
name: esggo-vps-sync-troubleshooting
description: ESGGO VPS 同步處理技巧，包含 SSH 金鑰還原、GitHub Actions 自動化部署與服務健康檢查
tags: [devops, vps, ssh, github-actions, pm2]
triggers:
  - vps sync
  - ssh key restore
  - github actions deploy
  - pm2 reload
  - esggo deploy

---

# ESGGO VPS 同步故障排除指南

## 1. 問題診斷

### SSH 連線失敗 (Permission denied (publickey))
- 檢查金鑰權限：`stat -c "%a" ~/.ssh/esggo_original` 應為 `600`
- 公鑰權限：應為 `644`
- 從備份還原：`cp ~/.ssh/esggo_original.bak.* ~/.ssh/esggo_original`

### 權限修復
```bash
# 還原私鑰
cp ~/.ssh/esggo_original.bak.20260804063842 ~/.ssh/esggo_original
chmod 600 ~/.ssh/esggo_original

# 重新生成公鑰
ssh-keygen -y -f ~/.ssh/esggo_original > ~/.ssh/esggo_original.pub
chmod 644 ~/.ssh/esggo_original.pub
```

## 2. VPS 端配置

```bash
# 設定 authorized_keys
cat ~/.ssh/esggo_original.pub >> ~/.ssh/authorized_keys
chmod 644 ~/.ssh/authorized_keys
chmod 700 ~/.ssh

# 重啟 SSH
sudo systemctl restart sshd

# 同步代碼
cd /opt/esggo
git pull origin main
pm2 reload ecosystem.config.js

# 驗證健康
curl -sS https://esggo.co/api/healthz
```

## 3. 自動化部署

### GitHub Actions 觸發
```bash
gh run list --branch main --limit 3
gh run rerun <failed-run-id>
```

### Cloudflare Tunnel 驗證
```bash
curl -sS https://esggo.co/api/health
curl -sS https://omniagent.esggo.co/health
```

## 4. 健康檢查

### API 端點
- `https://esggo.co/api/health` - 主體健康狀態
- `https://esggo.co/api/healthz` - 詳細組件檢查
- `https://omniagent.esggo.co/health` - OmniAgent 狀態

## 5. 常見問題解決方案

### Port 22 被阻擋
- 使用 Cloudflare Tunnel 替代方案
- 或檢查防火牆規則：`sudo ufw status`

### PM2 服務無回應
```bash
pm2 status
pm2 logs esggo-core --lines 20
pm2 restart esggo-core
```