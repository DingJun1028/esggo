---
name: esggo-deploy-push-merge
description: esggo GitHub push/merge, DeerFlow Docker, VPS Ollama setup.
---

# esggo-deploy-push-merge

Use this skill for the DingJun1028/esggo deployment lifecycle on the Windows host
(`C:\Project\esggo`) and the Oracle ARM VPS (`esggo-vps`, 161.118.248.180).

## 0. Pre-flight: terminal state recovery

The Hermes `terminal` tool can get LOCKED into SSH mode if `TERMINAL_SSH_HOST` /
`TERMINAL_SSH_USER` / `TERMINAL_SSH_PORT` env vars are set (e.g. by a prior
`hermes config set terminal.ssh_key` / SSH session). Symptom: every `terminal`
command exits -1 or tunnels to VPS instead of running locally, and the embedded
Hermes PowerShell pane shows a stale buffer and does NOT accept typed input
(marker-file write test fails).

**Fix:** Run `unset TERMINAL_SSH_HOST TERMINAL_SSH_USER TERMINAL_SSH_PORT` in the
terminal, then local git-bash commands work again at `/c/Project/esggo`. This
also restores real SSH (the broken terminal was a side effect of the lock).

## 1. Git push + merge strategy (CRITICAL)

Local repo: `C:\Project\esggo`, branch `main` (remote `origin` = github).
There are 100+ remote branches; MOST are bot/experimental
(`bolt-*`, `jules-*`, `sentinel-*`, `palette-*`, `perf/*`).

**Do NOT blindly merge all branches.** Merging 100+ bot branches into main causes
hundreds of conflicts and breaks the build.

Pattern that WORKED 2026-08-05:
- `new-branch` is **unrelated history** (independent root `a0be0409`, not forked
  from main). `git merge` → `fatal: refusing to merge unrelated histories`.
- Do a **file-level selective merge** instead:
  ```bash
  cd /c/Project/esggo
  git checkout main
  git checkout new-branch -- $(git ls-tree -r --name-only new-branch \
    | grep '\.tsx$' | grep -vF -f <(git ls-tree -r --name-only main))
  git checkout new-branch -- .eslintrc.json eslint.config.mjs
  # SKIP package-lock.json (pnpm monorepo uses pnpm-lock.yaml)
  git commit -m "merge: integrate new-branch unique views into main"
  git push origin main
  ```
- Untracked temp audit scripts (`_*.py`, `_*.json`) are NOT deployment artifacts
  → `rm -f` them, do not commit them.

Honest reporting: state which branches were merged (selective) vs skipped (bot
WIP) with reason. Never claim "all branches merged" if you only did selective.

## 2. DeerFlow local Docker startup

DeerFlow lives at `C:\Project\esggo-deerflow` (separate from esggo repo). It uses
`bytedance/deer-flow` 2.0. The user's `make docker-build` / `make docker-start`
commands: **`make` is often absent in git-bash**, and `make docker-build` is NOT
a real target (use `docker-init` or `make up`). Run the Makefile equivalents:

```bash
cd /c/Project/esggo-deerflow
python3 ./scripts/check.py          # = make check
bash ./scripts/docker.sh start       # = make docker-start
```

`make check` FAILS on `nginx` (local serve mode only) — **ignored for Docker
mode** (Docker uses in-container nginx). Docker mode needs only: node, pnpm, uv,
docker.

**Docker daemon must be running.** On Windows it is NOT auto-started. Launch:
```powershell
powershell.exe -NoProfile -Command "Start-Process 'C:\Program Files\Docker\Docker\Docker Desktop.exe'"
for i in $(seq 1 30); do docker info >/dev/null 2>&1 && break; sleep 3; done
```
Then `bash ./scripts/docker.sh start` builds images (~150s) and starts
redis/frontend/gateway/nginx. Verify: `curl -s -m 10 -o /dev/null -w "%{http_code}" http://127.0.0.1:2026/` → **HTTP 200**. Gateway `:8001` is container-internal only; external API is `http://localhost:2026/api/*`.

## 3. VPS Ollama + Qwen3-VL setup

SSH: `ssh -i $HOME/.ssh/esggo_original ubuntu@161.118.248.180`
(NEVER ssh-keygen -f over esggo_original — it's the live VPS key; restore from .bak if damaged.)

**DISK SPACE CHECK FIRST.** The VPS is a 45G Oracle ARM free tier. It fills up
(100% used) from docker build caches. Symptom: `docker run` →
`no space left on device` while extracting ollama CUDA libs.

Clean before install:
```bash
docker builder prune -f
docker image prune -f
df -h /                     # confirm free space > 6G
```
Then install Ollama via Docker (cleaner than bare-metal):
```bash
docker run -d --name ollama -p 11434:11434 --restart unless-stopped \
  -v ollama_data:/root/.ollama ollama/ollama:latest
```
Image pull is SLOW (~3-4GB, >180s) — run in `terminal(background=true,
notify_on_complete=true)` not foreground (foreground times out at 180s).

**HARDWARE LIMIT**: VPS is 1 OCPU / 6G RAM / **NO GPU** (CPU-only).
Qwen3-VL even at 2B is marginal on CPU. Pull the smallest VL model:
`docker exec ollama ollama pull qwen3-vl:2b` (or `qwen2.5vl:3b` as CPU fallback).
Expect very slow inference; document this limitation honestly.
Verify: `curl http://localhost:11434/api/tags`.

## 4. Verification gates (do not skip)

- Git: `git rev-list --left-right --count main...origin/main` → `0\t0` = synced.
- DeerFlow: HTTP 200 on :2026 + `docker ps` shows all 4 containers Up.
- Ollama: `curl localhost:11434/api/tags` returns JSON; model listed.

## 5. Pitfalls index
- Broken terminal = unset TERMINAL_SSH_* (§0).
- Embedded Hermes PowerShell pane does NOT accept input when stuck — use real
  terminal tool or `powershell.exe Start-Process` for GUI apps.
- new-branch = unrelated history → selective file merge, never `--allow-unrelated-histories`.
- 100+ remote branches = skip bot WIP, report honestly.
- DeerFlow: no `make` in git-bash; use `bash ./scripts/docker.sh`.
- Docker daemon not auto-started on Windows → PowerShell Start-Process.
- VPS disk full → prune before ollama; run pull in background.
- VPS no GPU → Qwen3-VL CPU-only, slow; pick smallest model.
